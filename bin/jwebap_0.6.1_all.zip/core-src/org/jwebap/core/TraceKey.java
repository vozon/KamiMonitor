package org.jwebap.core;


public interface TraceKey
{

    public abstract Object getInvokeKey();

    public abstract Object getThreadKey();
}
